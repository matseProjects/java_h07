
public class DasSpiel {
	public static void main(String[] args) {
		// boolean test = false == false;
		GefDilemma gd = new GefDilemma(new TitforTat(), new Random());
		gd.spiele(100);
		System.out.println(gd);
	}
}
