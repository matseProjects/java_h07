/**
 * 
 * @author lukas, markus
 * Repraesentiert die Strategie: Gleiche Entscheidungen in der vorherigen Runde fuehren zum Erzaehlen, Ungleiche zum Erzaehlen
 */
public class Pavlov implements GefStrategie {

	//In der ersten Runde soll kooperiert werden, deshalb unterschiedliche Werte
	private boolean oppenentsLastDecision = false;
	private boolean myLastDecision = true;
	
	@Override
	public boolean getNextDecision() {
		
		boolean equalDecisions = !(oppenentsLastDecision==myLastDecision);
		myLastDecision = equalDecisions;
		return equalDecisions;
	}

	@Override
	public void setOppenentsLastDecision(boolean decision) {
		this.oppenentsLastDecision = decision;
	}

}
